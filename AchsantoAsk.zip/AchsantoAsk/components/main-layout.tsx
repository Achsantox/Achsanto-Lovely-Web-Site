"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Heart, Copyright, Info } from "lucide-react"
import { ModeToggle } from "@/components/mode-toggle"
import { LoadingScreen } from "@/components/loading-screen"

export function MainLayout({ children }: { children: React.ReactNode }) {
  const [loading, setLoading] = useState(true)
  const [mounted, setMounted] = useState(false)

  // Hydration mismatch'i önlemek için
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <>
      {loading && <LoadingScreen onComplete={() => setLoading(false)} />}

      <div
        className={`relative min-h-screen overflow-hidden flex flex-col ${loading ? "opacity-0" : "opacity-100 transition-opacity duration-1000"}`}
      >
        <FloatingHearts />
        <header className="border-b animate-fade-in">
          <div className="container flex items-center justify-between py-4">
            <Link href="/" className="flex items-center gap-2 group">
              <Heart className="h-6 w-6 text-primary animate-pulse-slow" />
              <h1 className="text-2xl font-bold text-primary group-hover:scale-105 transition-transform">
                Aşığım sana...
              </h1>
            </Link>
            <ModeToggle />
          </div>
        </header>
        <main className="flex-grow">{children}</main>
        <footer className="border-t py-6 animate-fade-in">
          <div className="container">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <div className="flex items-center gap-2">
                <Copyright className="h-4 w-4 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">
                  {new Date().getFullYear()} Achsantodan tüm mutlu sevgililere ❤️
                </p>
              </div>
              <div className="flex gap-6">
                <Link
                  href="/copyright"
                  className="text-sm text-muted-foreground hover:text-primary transition-colors flex items-center gap-1"
                >
                  <Info className="h-4 w-4" />
                  Telif Hakkı Bilgileri
                </Link>
                <Link href="/terms" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Kullanım Koşulları
                </Link>
                <Link href="/privacy" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Gizlilik Politikası
                </Link>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </>
  )
}

function FloatingHearts() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
      {Array.from({ length: 30 }).map((_, i) => {
        const size = 20 + Math.random() * 30
        const duration = 15 + Math.random() * 20
        const delay = Math.random() * 15
        const rotation = Math.random() > 0.5 ? "animate-rotate" : ""

        return (
          <div
            key={i}
            className={`absolute text-primary opacity-20 animate-float ${rotation}`}
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${delay}s`,
              animationDuration: `${duration}s`,
              fontSize: `${size}px`,
            }}
          >
            ❤️
          </div>
        )
      })}
    </div>
  )
}
