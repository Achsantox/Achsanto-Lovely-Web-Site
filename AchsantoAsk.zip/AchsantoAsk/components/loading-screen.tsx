"use client"

import { useState, useEffect } from "react"
import { AnimatedHeart } from "./animated-heart"

const loadingMessages = [
  "Aşkımız Yükleniyor...",
  "Mektubumuzu yazıyorum...",
  "Anılarımızı topluyorum...",
  "Kalbimi hazırlıyorum...",
  "Sevgimizi dolduruyorum...",
  "Hayallerimizi kuruyorum...",
  "Özel anlarımızı hatırlıyorum...",
]

export function LoadingScreen({ onComplete }: { onComplete: () => void }) {
  const [progress, setProgress] = useState(0)
  const [messageIndex, setMessageIndex] = useState(0)
  const [showContent, setShowContent] = useState(true)

  useEffect(() => {
    // Change message every 2 seconds
    const messageInterval = setInterval(() => {
      setMessageIndex((prev) => (prev + 1) % loadingMessages.length)
    }, 2000)

    // Increase progress gradually
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressInterval)
          // Start fade out animation after reaching 100%
          setTimeout(() => {
            setShowContent(false)
            // Call onComplete after fade out animation
            setTimeout(onComplete, 1000)
          }, 1500)
          return 100
        }
        return prev + 0.5
      })
    }, 50)

    return () => {
      clearInterval(messageInterval)
      clearInterval(progressInterval)
    }
  }, [onComplete])

  if (!showContent) return null

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-background transition-opacity duration-1000">
      <div className="relative flex flex-col items-center">
        <AnimatedHeart progress={progress} />
      </div>

      {/* Loading message */}
      <div className="mt-8 h-8 text-center">
        <p className="animate-text-fade text-xl font-medium text-primary">{loadingMessages[messageIndex]}</p>
      </div>

      {/* Show a special message when loading is complete */}
      {progress === 100 && (
        <div className="mt-4 animate-fade-in">
          <p className="text-lg font-medium text-primary">Aşkımız Hazır! ❤️</p>
        </div>
      )}
    </div>
  )
}
