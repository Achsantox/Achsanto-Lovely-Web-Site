"use client"

export function AnimatedHeart({ progress }: { progress: number }) {
  return (
    <div className={`relative h-40 w-40 ${progress === 100 ? "animate-heartbeat" : ""}`}>
      {/* Heart outline */}
      <svg
        viewBox="0 0 24 24"
        className="absolute h-full w-full text-primary/20"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
      >
        <path d="M19.5 12.572l-7.5 7.428l-7.5 -7.428a5 5 0 1 1 7.5 -6.566a5 5 0 1 1 7.5 6.566" />
      </svg>

      {/* Heart fill with clip path */}
      <div
        className="absolute h-full w-full overflow-hidden"
        style={{
          clipPath: `inset(${100 - progress}% 0 0 0)`,
          transition: "clip-path 0.3s ease-out",
        }}
      >
        <svg viewBox="0 0 24 24" className="h-full w-full text-primary" fill="currentColor">
          <path d="M19.5 12.572l-7.5 7.428l-7.5 -7.428a5 5 0 1 1 7.5 -6.566a5 5 0 1 1 7.5 6.566" />
        </svg>
      </div>

      {/* Progress text */}
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-2xl font-bold text-white drop-shadow-md">{Math.round(progress)}%</span>
      </div>
    </div>
  )
}
