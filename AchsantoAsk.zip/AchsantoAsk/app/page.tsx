import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Heart, Camera, Book, Mail } from "lucide-react"

export default function Home() {
  return (
    <div className="container py-12">
      <section className="mb-12 text-center animate-fade-in">
        <Heart className="mx-auto h-12 w-12 text-primary animate-pulse-slow mb-4" />
        <h1 className="mb-4 text-4xl font-bold tracking-tight">Aşk Hikayemiz</h1>
        <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
          Yolculuğumuzu, anılarımızı ve aşkımızı paylaştığımız özel yerimize hoş geldiniz.
        </p>
      </section>

      <section className="grid gap-6 md:grid-cols-3 mt-8 stagger-fade-in">
        <Card className="overflow-hidden transition-all hover:shadow-lg hover-scale">
          <CardContent className="p-0">
            <Link href="/gallery" className="block p-6 text-center">
              <Camera className="mx-auto mb-4 h-12 w-12 text-primary animate-bounce-slow" />
              <h2 className="mb-2 text-2xl font-semibold">Fotoğraf Galerisi</h2>
              <p className="text-muted-foreground">En sevdiğimiz anları keşfedin</p>
            </Link>
          </CardContent>
        </Card>

        <Card className="overflow-hidden transition-all hover:shadow-lg hover-scale">
          <CardContent className="p-0">
            <Link href="/journey" className="block p-6 text-center">
              <Book className="mx-auto mb-4 h-12 w-12 text-primary animate-bounce-slow" />
              <h2 className="mb-2 text-2xl font-semibold">Yolculuğumuz</h2>
              <p className="text-muted-foreground">Nasıl tanıştığımızın ve maceralarımızın hikayesi</p>
            </Link>
          </CardContent>
        </Card>

        <Card className="overflow-hidden transition-all hover:shadow-lg hover-scale">
          <CardContent className="p-0">
            <Link href="/letters" className="block p-6 text-center">
              <Mail className="mx-auto mb-4 h-12 w-12 text-primary animate-bounce-slow" />
              <h2 className="mb-2 text-2xl font-semibold">Aşk Mektupları</h2>
              <p className="text-muted-foreground">Kalpten gelen özel mesajlar</p>
            </Link>
          </CardContent>
        </Card>
      </section>

      <section className="mt-16 animate-fade-in" style={{ animationDelay: "0.4s" }}>
        <Card className="hover-scale">
          <CardContent className="p-6 md:p-10">
            <h2 className="mb-6 text-3xl font-bold text-center">Hayat Hikayemiz</h2>
            <div className="prose prose-pink dark:prose-invert mx-auto max-w-3xl">
              <p className="text-lg leading-relaxed">Sevgilim,</p>
              <p className="text-lg leading-relaxed">
                Yollarımızın kesiştiği andan itibaren, sende özel bir şey olduğunu biliyordum. Gülüşün, kahkahanın sesi
                ve gözlerindeki sıcaklık ilk günden beni büyüledi.
              </p>
              <p className="text-lg leading-relaxed">
                Birlikte geçirdiğimiz yolculuk sayısız güzel anılarla dolu - kapanış saatine kadar konuştuğumuz o küçük
                kafedeki ilk randevumuzdan, birlikte seyahat ettiğimiz maceralara, yeni yerler keşfetmeye ve ömür boyu
                sürecek anılar biriktirmeye kadar.
              </p>
              <p className="text-lg leading-relaxed">
                İnişler ve çıkışlar boyunca, aşkın benim sabitim, çapam, evim oldu. Bana gerçekten sevmeyi ve
                karşılığında sevilmeyi öğrettin.
              </p>
              <p className="text-lg leading-relaxed">
                Hikayemizi birlikte yazmaya devam ederken, henüz gelmemiş olan tüm bölümler için heyecanlıyım. Seninle
                geçirdiğim her gün bir nimet ve paylaştığımız her anı değerli buluyorum.
              </p>
              <p className="text-lg leading-relaxed">Sonsuza dek senin,</p>
              <p className="text-lg font-semibold">Tüm kalbimle ❤️</p>
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  )
}
