import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import { Shield, ArrowLeft } from "lucide-react"

export default function PrivacyPage() {
  return (
    <div className="container py-12 animate-fade-in">
      <Link href="/" className="flex items-center gap-2 text-primary hover:underline mb-8">
        <ArrowLeft className="h-4 w-4" />
        Ana Sayfaya Dön
      </Link>

      <Card>
        <CardContent className="p-6 md:p-10">
          <div className="flex items-center gap-2 mb-6">
            <Shield className="h-6 w-6 text-primary" />
            <h1 className="text-3xl font-bold">Gizlilik Politikası</h1>
          </div>

          <div className="prose prose-pink dark:prose-invert max-w-none">
            <h2>Topladığımız Bilgiler</h2>
            <p>
              Sitede gizliliğinize saygı duyar. Bu web sitesi, tarafınızdan açıkça sağlanmadığı sürece
              kişisel bilgileri toplamaz.
            </p>

            <h2>Bilgilerinizi Nasıl Kullanıyoruz</h2>
            <p>
              Toplanan herhangi bir bilgi yalnızca sağlandığı amaç için kullanılır ve açık izniniz olmadan üçüncü
              taraflarla paylaşılmaz.
            </p>

            <h2>Çerezler</h2>
            <p>
              Bu web sitesi, tarama deneyiminizi geliştirmek için çerezleri kullanır. Çerezler, web sitesinin daha iyi
              bir kullanıcı deneyimi sağlamasına yardımcı olmak için cihazınıza yerleştirilen küçük metin dosyalarıdır.
              Tarayıcı ayarlarınızdan çerezleri devre dışı bırakmayı seçebilirsiniz, ancak bu, web sitesindeki
              deneyiminizi etkileyebilir.
            </p>

            <h2>Üçüncü Taraf Bağlantıları</h2>
            <p>
              Web sitemiz üçüncü taraf web sitelerine bağlantılar içerebilir. Bu sitelerin içeriği ve uygulamaları
              üzerinde hiçbir kontrolümüz yoktur ve ilgili gizlilik politikaları için sorumluluk kabul edemeyiz.
            </p>

            <h2>Haklarınız</h2>
            <p>
              Hakkınızda sahip olabileceğimiz herhangi bir kişisel bilgiye erişme, düzeltme veya silme hakkına
              sahipsiniz. Bu hakları kullanmak isterseniz, lütfen aşağıda verilen bilgileri kullanarak bizimle iletişime
              geçin.
            </p>

            <h2>Bu Politikadaki Değişiklikler</h2>
            <p>
              Gizlilik Politikamızı zaman zaman güncelleyebiliriz. Yeni Gizlilik Politikasını bu sayfada yayınlayarak
              sizi herhangi bir değişiklik hakkında bilgilendireceğiz.
            </p>

            <h2>Bize Ulaşın</h2>
            <p>
              Bu Gizlilik Politikası hakkında herhangi bir sorunuz varsa, lütfen bizimle iletişime geçin:
              <br />
              <a href="mailto:savararap4@gmail.com" className="text-primary">
                gizlilik@achsanto-ask.ornek.com
              </a>
            </p>

            <p className="text-sm text-muted-foreground mt-8">Son güncelleme: {new Date().toLocaleDateString()}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
