import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function LettersPage() {
  const letters = [
    {
      id: "anniversary",
      title: "Aşk Mektubu",
      preview: "...",
    },
    {
      id: "birthday",
      title: "Doğum Günün..",
      preview: "...",
    },
    {
      id: "just-because",
      title: "Sadece Öylesine",
      preview: "...",
    },
    {
      id: "future",
      title: "Geleceğimize",
      preview: "...",
    },
  ]

  return (
    <div className="container py-12">
      <Link href="/" className="flex items-center gap-2 text-primary hover:underline mb-8 animate-fade-in">
        <ArrowLeft className="h-4 w-4" />
        Ana Sayfaya Dön
      </Link>

      <div className="mb-8 text-center animate-fade-in">
        <h1 className="mb-4 text-3xl font-bold">Sana olan DUYGULARIM</h1>
        <p className="mx-auto max-w-2xl text-muted-foreground">
          Benden gelen mektupları gör..
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {letters.map((letter) => (
          <Link key={letter.id} href={`/letters/${letter.id}`}>
            <Card className="h-full transition-all hover:shadow-lg">
              <CardContent className="flex h-full flex-col p-6">
                <div className="mb-4 text-right text-muted-foreground">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="inline-block"
                  >
                    <path d="M22 13V6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h9" />
                    <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold">{letter.title}</h3>
                <p className="mt-2 text-muted-foreground">{letter.preview}</p>
                <div className="mt-auto pt-4 text-sm text-primary">Devamını okumak için tıklayın</div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}
