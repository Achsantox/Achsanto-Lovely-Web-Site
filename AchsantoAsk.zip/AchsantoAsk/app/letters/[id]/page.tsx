import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import { notFound } from "next/navigation"
import { ArrowLeft } from "lucide-react"

// Define the letter content
const letters = {
  anniversary: {
    title: "Aşk Mektubu",
    date: "Aşkım",
    content: `
      Sevgilim,

      doldurulcak
      Tüm kalbimle ❤️
    `,
  },
  birthday: {
    title: "Doğum Günün...",
    date: "iyiki doğdun..",
    content: `
      doldurulcak
      Sonsuza dek ve daima ❤️
    `,
  },
  "just-because": {
    title: "Sadece Öylesine",
    date: "Herhangi Bir Gün",
    content: `
      sadece seninim...
      Tüm kalbimle ❤️
    `,
  },
  future: {
    title: "Geleceğimize",
    date: "İleriye Bakış",
    content: `
     doldurulcak
      Tüm kalbimle ❤️
    `,
  },
}

export default function LetterPage({ params }: { params: { id: string } }) {
  const letter = letters[params.id as keyof typeof letters]

  if (!letter) {
    notFound()
  }

  return (
    <div className="container py-12">
      <Link href="/letters" className="flex items-center gap-2 text-primary hover:underline mb-8 animate-fade-in">
        <ArrowLeft className="h-4 w-4" />
        Mektuplara Dön
      </Link>

      <Card className="mx-auto max-w-3xl">
        <CardContent className="p-6 md:p-10">
          <div className="mb-6 text-center">
            <h1 className="mb-2 text-3xl font-bold">{letter.title}</h1>
            <p className="text-muted-foreground">{letter.date}</p>
          </div>

          <div className="prose prose-pink dark:prose-invert mx-auto max-w-none">
            {letter.content.split("\n").map((paragraph, index) => (
              <p key={index} className="mb-4 leading-relaxed">
                {paragraph.trim()}
              </p>
            ))}
          </div>

          <div className="mt-8 text-center">
            <Link href="/letters" className="text-primary hover:underline">
              Mektuplara Dön
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
