"use client"

import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { useEffect, useState } from "react"

export default function ThemeTest() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  // Avoid hydration mismatch
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="p-4 border rounded-lg mt-8">
      <h2 className="text-xl font-bold mb-4">Theme Tester</h2>
      <p className="mb-2">
        Current theme: <span className="font-bold">{theme}</span>
      </p>
      <div className="flex gap-2 mt-4">
        <Button onClick={() => setTheme("dark")}>Set Dark</Button>
        <Button onClick={() => setTheme("pink")}>Set Pink</Button>
      </div>
    </div>
  )
}
