import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import { FileText, ArrowLeft } from "lucide-react"

export default function TermsPage() {
  return (
    <div className="container py-12 animate-fade-in">
      <Link href="/" className="flex items-center gap-2 text-primary hover:underline mb-8">
        <ArrowLeft className="h-4 w-4" />
        Ana Sayfaya Dön
      </Link>

      <Card>
        <CardContent className="p-6 md:p-10">
          <div className="flex items-center gap-2 mb-6">
            <FileText className="h-6 w-6 text-primary" />
            <h1 className="text-3xl font-bold">Kullanım Koşulları</h1>
          </div>

          <div className="prose prose-pink dark:prose-invert max-w-none">
            <h2>Koşulların Kabulü</h2>
            <p>
              Bu web sitesine erişerek ve kullanarak, bu anlaşmanın şartlarını ve hükümlerini kabul etmiş ve bunlarla
              bağlı olmayı kabul etmiş olursunuz.
            </p>

            <h2>Kullanım Lisansı</h2>
            <p>
              Sitemdeki materyalleri yalnızca kişisel, ticari olmayan kullanım için geçici olarak
              görüntüleme izni verilmiştir. Bu, bir başlık devri değil, bir lisans verilmesidir.
            </p>

            <h2>Sorumluluk Reddi</h2>
            <p>
              Bu web sitesindeki materyaller "olduğu gibi" temelinde sağlanmaktadır, açık veya
              zımni hiçbir garanti vermez ve burada, sınırlama olmaksızın, ticarete elverişlilik, belirli bir amaca
              uygunluk veya fikri mülkiyet veya diğer hakların ihlal edilmemesi ile ilgili zımni garantiler veya
              koşullar dahil olmak üzere diğer tüm garantileri reddeder ve geçersiz kılar.
            </p>

            <h2>Sınırlamalar</h2>
            <p>
              Hiçbir durumda Sitem veya tedarikçileri, Diyar veya yetkili bir temsilcisi bu
              tür bir zararın olasılığı hakkında sözlü veya yazılı olarak bilgilendirilmiş olsa bile, bu web sitesindeki
              materyallerin kullanımından veya kullanılamamasından kaynaklanan herhangi bir zarardan sorumlu tutulamaz.
            </p>

            <h2>Düzeltmeler ve Hatalar</h2>
            <p>
              Bu web sitesinde görünen materyaller teknik, tipografik veya fotografik hatalar içerebilir. web sitesindeki materyallerin hiçbirinin doğru, eksiksiz veya güncel olduğunu garanti etmez.
            </p>

            <h2>Bağlantılar</h2>
            <p>
              Özel sitem, web sitesine bağlantılı tüm siteleri incelememiştir ve bu tür bağlantılı herhangi bir
              sitenin içeriğinden sorumlu değildir. Herhangi bir bağlantının dahil edilmesi, 
              tarafından sitenin onaylandığı anlamına gelmez. Bu tür bağlantılı herhangi bir web sitesinin kullanımı
              kullanıcının kendi sorumluluğundadır.
            </p>

            <h2>Değişiklikler</h2>
            <p>
              Sitemdeki, web sitesi için bu kullanım koşullarını herhangi bir zamanda önceden haber
              vermeksizin revize edebilir. Bu web sitesini kullanarak, bu hizmet şartlarının o sırada geçerli olan
              versiyonuna bağlı olmayı kabul etmiş olursunuz.
            </p>

            <p className="text-sm text-muted-foreground mt-8">Son güncelleme: {new Date().toLocaleDateString()}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
