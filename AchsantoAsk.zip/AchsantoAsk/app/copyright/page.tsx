import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import { Copyright, ArrowLeft } from "lucide-react"

export default function CopyrightPage() {
  return (
    <div className="container py-12 animate-fade-in">
      <Link href="/" className="flex items-center gap-2 text-primary hover:underline mb-8">
        <ArrowLeft className="h-4 w-4" />
        Ana Sayfaya Dön
      </Link>

      <Card>
        <CardContent className="p-6 md:p-10">
          <div className="flex items-center gap-2 mb-6">
            <Copyright className="h-6 w-6 text-primary" />
            <h1 className="text-3xl font-bold">Telif Hakkı Bilgileri</h1>
          </div>

          <div className="prose prose-pink dark:prose-invert max-w-none">
            <h2>İçerik Telif Hakkı</h2>
            <p>
              Bu web sitesindeki metin, grafikler, logolar, görseller, ses klipleri, dijital indirmeler ve veri
              derlemeleri dahil ancak bunlarla sınırlı olmamak üzere tüm içerik, Achsanto Aşk Sitesi'nin mülkiyetindedir
              ve uluslararası telif hakkı yasaları tarafından korunmaktadır.
            </p>

            <h2>Kişisel Kullanım</h2>
            <p>
              Bu web sitesi kişisel, ticari olmayan kullanım için tasarlanmıştır. Bu web sitesinin içeriği, Achsanto Aşk
              Sitesi'nin önceden yazılı izni olmadan çoğaltılamaz, dağıtılamaz, iletilemez, önbelleğe alınamaz veya
              başka bir şekilde kullanılamaz.
            </p>

            <h2>Görsel Kullanımı</h2>
            <p>
              Bu web sitesinde görüntülenen görseller ya bize aittir ya da izinle kullanılmaktadır. Bu görsellerin
              izinsiz kullanımı kesinlikle yasaktır. Bu sitedeki herhangi bir içeriğin telif hakkınızı ihlal ettiğini
              düşünüyorsanız, lütfen hemen bizimle iletişime geçin.
            </p>

            <h2>Üçüncü Taraf İçeriği</h2>
            <p>
              Bu web sitesindeki bazı içerik veya işlevler, animasyonlar, simgeler ve tasarım öğeleri dahil ancak
              bunlarla sınırlı olmamak üzere üçüncü taraflarca sağlanabilir. Bu üçüncü tarafların, talep üzerine sunulan
              kendi telif hakkı ve lisanslama koşulları olabilir.
            </p>

            <h2>Adil Kullanım</h2>
            <p>
              İçeriğin sınırlı alıntılanmasına, Achsanto Aşk Sitesi'ne açık bir şekilde atıfta bulunulması ve içeriğe
              geri bir bağlantı (uygulanabilir olduğunda) verilmesi koşuluyla izin verilir. Bu, ABD Telif Hakkı
              Yasası'nın 107. bölümünde belirtildiği gibi materyalimizin "adil kullanımını" oluşturur.
            </p>

            <h2>İletişim Bilgileri</h2>
            <p>
              Telif hakkı politikamız hakkında herhangi bir sorunuz veya endişeniz varsa, lütfen bizimle iletişime
              geçin:
              <br />
              <a href="mailto:iletisim@achsanto-ask.ornek.com" className="text-primary">
                iletisim@achsanto-ask.ornek.com
              </a>
            </p>

            <p className="text-sm text-muted-foreground mt-8">Son güncelleme: {new Date().toLocaleDateString()}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
