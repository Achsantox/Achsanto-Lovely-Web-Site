import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft } from "lucide-react"

export default function GalleryPage() {
  // Sample gallery data
  const photos = [
    { id: 1, title: "İlk Buluşma", description: "Her şeyin başladığı yer" },
    { id: 2, title: "Plaj Tatili", description: "Birlikte ilk seyahatimiz" },
    { id: 3, title: "Yıldönümü Yemeği", description: "Aşkımızı kutluyoruz" },
    { id: 4, title: "Doğa Yürüyüşü", description: "Doğayı birlikte keşfediyoruz" },
    { id: 5, title: "Film Gecesi", description: "Evde geçirdiğimiz keyifli akşamlar" },
    { id: 6, title: "Doğum Günü Kutlaması", description: "Özel anlar" },
    { id: 7, title: "Kış Masalı", description: "Karlı gün anıları" },
    { id: 8, title: "Gün Batımı Yürüyüşü", description: "Güzel akşam gezintileri" },
    { id: 9, title: "Birlikte Yemek Yapma", description: "Lezzetli anılar yaratıyoruz" },
  ]

  return (
    <div className="container py-12">
      <Link href="/" className="flex items-center gap-2 text-primary hover:underline mb-8 animate-fade-in">
        <ArrowLeft className="h-4 w-4" />
        Ana Sayfaya Dön
      </Link>

      <div className="mb-8 text-center animate-fade-in">
        <h1 className="mb-4 text-3xl font-bold">Fotoğraf Galerimiz</h1>
        <p className="mx-auto max-w-2xl text-muted-foreground">En sevdiğimiz anların ve hatıraların bir koleksiyonu</p>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 stagger-fade-in">
        {photos.map((photo) => (
          <Card key={photo.id} className="overflow-hidden transition-all hover:shadow-lg hover-scale">
            <CardContent className="p-0">
              <div className="aspect-square relative">
                <Image
                  src={`/placeholder.svg?height=400&width=400&text=${photo.title}`}
                  alt={photo.title}
                  fill
                  className="object-cover"
                />
              </div>
              <div className="p-4">
                <h3 className="text-xl font-semibold">{photo.title}</h3>
                <p className="text-muted-foreground">{photo.description}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
