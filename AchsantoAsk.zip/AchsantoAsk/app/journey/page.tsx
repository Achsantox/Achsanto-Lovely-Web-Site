import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft } from "lucide-react"

export default function JourneyPage() {
  const journeySteps = [
    {
      id: 1,
      title: "İlk tanışmamız",
      date: "3 mayıs 2025",
      description:
        "doldurulcak",
      image: "ilk-karsilasma",
    },
    {
      id: 2,
      title: "İlk İltifat..",
      date: "3 mayıs 2025",
      description:
        "doldurulcak",
      image: "ilk-bulusma",
    },
    {
      id: 3,
      title: "ciddili ilişki",
      date: "3 mayıs 2025",
      description:
        "doldurulcak",
      image: "resmi-iliski",
    },
    {
      id: 4,
      title: "İlk buluşmamız",
      date: "3 mayıs 2025",
      description: "doldurulcak",
      image: "ilk-seyahat",
    },
    {
      id: 5,
      title: "Birlikte uyuma",
      date: "3 mayıs 2025",
      description: "İlişkimizde bir sonraki adımı attık. İlk evimizi birlikte kurduk.",
      image: "birlikte-tasinma",
    },
    {
      id: 6,
      title: "Bugün ve Sonrası",
      date: "Şimdi",
      description: "doldurulcak.",
      image: "bugun",
    },
  ]

  return (
    <div className="container py-12">
      <Link href="/" className="flex items-center gap-2 text-primary hover:underline mb-8 animate-fade-in">
        <ArrowLeft className="h-4 w-4" />
        Ana Sayfaya Dön
      </Link>

      <div className="mb-8 text-center animate-fade-in">
        <h1 className="mb-4 text-3xl font-bold">Birlikte Yolculuğumuz</h1>
        <p className="mx-auto max-w-2xl text-muted-foreground">En başından şimdiye kadar aşkımızın hikayesi</p>
      </div>

      <div className="relative mx-auto max-w-3xl">
        <div className="absolute left-1/2 top-0 h-full w-0.5 -translate-x-1/2 bg-primary/20"></div>

        {journeySteps.map((step, index) => (
          <div key={step.id} className="relative mb-12">
            <div className={`flex items-center ${index % 2 === 0 ? "flex-row" : "flex-row-reverse"}`}>
              <div className="w-1/2 px-4">
                <Card className="overflow-hidden">
                  <CardContent className="p-0">
                    <div className="aspect-video relative">
                      <Image
                        src={`/placeholder.svg?height=300&width=500&text=${step.image}`}
                        alt={step.title}
                        fill
                        className="object-cover"
                      />
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="absolute left-1/2 -translate-x-1/2 flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground">
                {step.id}
              </div>

              <div className="w-1/2 px-4">
                <div className={`text-left ${index % 2 !== 0 ? "text-right" : ""}`}>
                  <h3 className="text-xl font-semibold">{step.title}</h3>
                  <p className="text-sm text-muted-foreground">{step.date}</p>
                  <p className="mt-2">{step.description}</p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
